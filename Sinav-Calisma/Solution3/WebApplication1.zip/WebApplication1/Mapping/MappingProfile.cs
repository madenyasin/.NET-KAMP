﻿using AutoMapper;

namespace WebApplication1.Mapping
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            
        }
    }
}
